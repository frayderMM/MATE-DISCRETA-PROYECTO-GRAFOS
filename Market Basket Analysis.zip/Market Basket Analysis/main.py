from Producto import Producto
from Nodo import Nodo
from Grafo import Grafo
from preguntas import *

def main():
    # Crear productos de ejemplo
    producto1 = Producto(1, "Leche", 1.5)
    producto2 = Producto(2, "Pan", 0.5)
    producto3 = Producto(3, "Huevos", 2.0)
    producto4 = Producto(4, "Queso", 3.0)
    producto5 = Producto(5, "Mantequilla", 2.5)

    # Crear grafo
    grafo = Grafo()

    # Ejemplo de uso
    transactions = [
        {"leche", "pan", "huevos"},
        {"leche", "pan"},
        {"leche", "huevos"},
        {"pan", "huevos"},
        {"leche", "pan", "huevos"},
        {"mantequilla", "huevos"},
    ]
    build_cooccurrence_graph(transactions,2)



if __name__ == "__main__":
    main()
