from Producto import Producto
from Nodo import Nodo
from Grafo import Grafo
from itertools import combinations

### pregunta 006
### pregunta 007
def build_cooccurrence_graph(transactions, k):
    # Crear instancia del grafo
    grafo = Grafo()
    
    # Diccionario para contar co-ocurrencias de pares de artículos
    cooccurrence_counts = {}

    # Contar las veces que cada par de artículos aparece en las transacciones
    for transaction in transactions:
        for item1, item2 in combinations(transaction, 2):
            pair = frozenset((item1, item2))
            cooccurrence_counts[pair] = cooccurrence_counts.get(pair, 0) + 1

    # Crear nodos para cada artículo único
    productos = {}
    for transaction in transactions:
        for item in transaction:
            if item not in productos:
                print(item)
                productos[item] = Producto(len(productos)+1, item, 0)  # Crear Producto con id único
                grafo.agregar_nodo(productos[item])

    # Agregar aristas para los pares de artículos que cumplen con la frecuencia mínima
    for pair, count in cooccurrence_counts.items():
        if count >= k:
            item1, item2 = tuple(pair)
            grafo.agregar_arista(productos[item1], productos[item2])

    # Graficar el grafo
    return grafo
            
### pregunta 008


