from Nodo import Nodo

class Grafo:
    def __init__(self):
        self.listaNodos = {}
    
    def agregar_persona(self, id, nombre):

        if id not in self.listaNodos:
            self.listaNodos[id] = Nodo(id, nombre)  # key = id ; value = Nodo
        else:
            print("El Usuario ya existe")

    def agregar_amistad(self, id1, id2):
        if id1 in self.listaNodos and id2 in self.listaNodos:
            self.listaNodos[id1].anadirAmigos(self.listaNodos[id2]) 
            self.listaNodos[id2].anadirAmigos(self.listaNodos[id1])  

    def show(self):
        print(self.listaNodos)


