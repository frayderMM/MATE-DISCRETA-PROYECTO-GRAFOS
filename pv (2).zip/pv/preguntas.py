from Grafo import Grafo
from collections import deque

def find_friend_groups_dfs(grafo):
    visitados = set()
    grupos = 0

    # Itera sobre las claves (nodos) del diccionario de nodos
    for nodo in grafo.listaNodos.values():
        if nodo not in visitados:
            dfs(nodo, visitados)
            grupos += 1
    return grupos


def find_friend_groups_bfs(grafo):
    visitados = set()
    grupos = 0

    # Itera sobre las claves (nodos) del diccionario de nodos
    for nodo in grafo.listaNodos.values():
        if nodo not in visitados:
            bfs(nodo, visitados)
            grupos += 1
    return grupos


def dfs(nodo, visitados):
    visitados.add(nodo)
    for amigo in nodo.amigos:
        if amigo not in visitados:
            dfs(amigo, visitados)
            


def bfs(nodo, visitados):
    cola = deque([nodo])
    visitados.add(nodo)
    while cola:
        actual = cola.popleft()
        for amigo in actual.amigos:
            if amigo not in visitados:
                visitados.add(amigo)
                cola.append(amigo)
