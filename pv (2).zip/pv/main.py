# main.py
from Grafo import Grafo
from preguntas import *

def main():
    grafo = Grafo()
    grafo.agregar_persona(1, 'Alice')
    grafo.agregar_persona(2, 'Bob')
    grafo.agregar_persona(3, 'Charlie')

    grafo.agregar_persona(4, 'juan')
    grafo.agregar_persona(5, 'rocio')
    grafo.agregar_persona(6, 'ruth')

    grafo.agregar_amistad(1, 2)
    grafo.agregar_amistad(1, 3)
    grafo.agregar_amistad(4, 5)
    grafo.agregar_amistad(5, 6)


    #grafo.show()

    #pregunta 001
    print("Número de grupos por BFS : ", find_friend_groups_bfs(grafo))
    print("Número de grupos por DFS : ", find_friend_groups_dfs(grafo))

if __name__ == "__main__":
    main()
