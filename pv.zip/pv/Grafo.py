from Nodo import Nodo

class Grafo:
    def __init__(self):
        self.listaNodos = {}
    
    def agregar_persona(self, id, nombre):
        if id not in self.listaNodos:
            self.listaNodos[id] = Nodo(id, nombre)

    def agregar_amistad(self, id1, id2):
        if id1 in self.listaNodos and id2 in self.listaNodos:
            self.listaNodos[id1].anadirAmigos(self.listaNodos[id2])  # Grafo no dirigido
            self.listaNodos[id2].anadirAmigos(self.listaNodos[id1])  # Relación bidireccional

    def show(self):
        for id, nodo in self.listaNodos.items():
            amigos = [amigo.nombre for amigo in nodo.amigos]
            print(f"Persona {nodo.nombre} (ID: {id}) tiene los siguientes amigos: {', '.join(amigos) if amigos else 'No tiene amigos'}")

    def mostrarPersona(self, id):
        print(self.listaNodos.get(id))
    
            
