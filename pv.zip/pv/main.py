# main.py

from Grafo import Grafo

def main():
    grafo = Grafo()
    grafo.agregar_persona(1, 'Alice')
    grafo.agregar_persona(2, 'Bob')
    grafo.agregar_persona(3, 'Charlie')

    grafo.agregar_amistad(1, 2)
    grafo.agregar_amistad(1, 3)

    grafo.mostrarPersona(2)

    grafo.show()
if __name__ == "__main__":
    main()
